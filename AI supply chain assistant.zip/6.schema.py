import sqlite3
import pandas as pd

def schema_context(db_path="supply_chain.db"):
     conn = sqlite3.connect(db_path)

     tables = pd.read_sql(
         "SELECT name FROM sqlite_master WHERE type='table'", 
         conn
     )["name"].tolist()


     blocks = []

     for table in tables:
        cols_info = pd.read_sql(
            f"PRAGMA table_info({table})",
            conn
        )

        col_lines = []
        for _, row in cols_info.iterrows():
            line = f"  - {row['name']} ({row['type']})"
            col_lines.append(line)
 
        sample = pd.read_sql(f"SELECT * FROM {table} LIMIT 2", conn)
 
        blocks.append(
            f"Table: {table}\n"
            f"Columns: \n{chr(10).join(col_lines)}\n"
            f"Sample rows: \n{sample.to_string(index=False)}"
        )
 
     conn.close()

     relationships = """
Table Relationships:
- orders.order_id -> delivery.order_id
- orders.order_id -> returns.order_id
- orders.customer_id -> returns.customer_id
- orders.product_id -> products.product_id
- orders.product_id -> inventory.product_id
- orders.store_id -> warehouses.store_id
- orders.store_id -> inventory.store_id
- returns.product_id -> products.product_id
- returns.store_id -> warehouses.store_id
- inventory.store_id -> warehouses.store_id
- inventory.product_id -> products.product_id

Known data notes:
- delivery.pickup_time and delivery.delivery_end_time are text in MM:SS.f format. They are the
minute:second part of the CLOCK time (the hour is missing), so they repeat every hour.
delivery.pickup_time_seconds and delivery.delivery_end_time_seconds are those same clock values in
seconds (0-3600). They are NOT durations: never average, sum or compare them as durations or delays.
- To measure delivery time or delay, use only the order timestamps (SQLite):
  delivery duration in minutes = (julianday(orders.actual_delivery_time) - julianday(orders.order_date_time)) * 1440
  delay in minutes = (julianday(orders.actual_delivery_time) - julianday(orders.expected_delivery_time)) * 1440
  An order is late when actual_delivery_time > expected_delivery_time. The promise is 10 minutes.
- For any date/time filtering or period comparisons, use 
orders.order_date_time, orders.expected_delivery_time, 
orders.actual_delivery_time, inventory.last_updated, or returns.return_date.
"""
     return "\n\n".join(blocks) + "\n\n" + relationships


if __name__ == "__main__":
    schema = schema_context()
    print(schema)
    with open("schema.txt", "w", encoding="utf-8") as f:
        f.write(schema)

