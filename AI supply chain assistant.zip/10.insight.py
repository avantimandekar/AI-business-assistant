import os
from google import genai

client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])


def call_llm(client, prompt, model="gemini-3.6-flash", retries=4):
    """Calls Gemini and retries on temporary overload (503) or rate-limit (429) errors."""
    import time
    for attempt in range(retries):
        try:
            return client.models.generate_content(model=model, contents=prompt).text.strip()
        except Exception as e:
            temporary = any(code in str(e) for code in ("503", "UNAVAILABLE", "429"))
            if temporary and attempt < retries - 1:
                time.sleep(3 * (attempt + 1))
                continue
            raise


def generate_insight(question, result_df, max_rows=15):
    """
    Turns a SQL result into a manager-ready business explanation. Works for any question.
    Only sends a small sample + summary stats to the LLM, never the full table,
    to avoid blowing past free-tier token limits on large results.
    """
    if result_df.empty:
        return "No data was returned for this question, so no insight can be generated."

    total_rows = len(result_df)
    sample_preview = result_df.head(max_rows).to_string(index=False)

    numeric_cols = result_df.select_dtypes(include="number").columns.tolist()
    summary_text = ""
    if numeric_cols:
        summary_text = result_df[numeric_cols].describe().round(2).to_string()

    prompt = f"""You are a business analyst reporting to a non-technical manager.

Question asked: "{question}"

The query returned {total_rows} total rows. Here is a sample of {min(max_rows, total_rows)} rows:
{sample_preview}

Summary statistics for numeric columns across all {total_rows} rows:
{summary_text if summary_text else "N/A"}

Write:
1. One sentence stating the overall finding.
2. Up to 3 bullet points citing the most notable patterns or numbers in the data.

Base everything strictly on the data shown above. Columns named pickup_time_seconds and delivery_end_time_seconds are clock readings, not durations; do not describe them as delays or waiting times. If the rows look like a top-N or a subset (for example the worst groups only), say the figures apply only to those rows and do not describe them as all stores or the whole dataset. Do not invent numbers or causes
not supported by the data.
"""

    return call_llm(client, prompt)


if __name__ == "__main__":
    import importlib.util

    spec = importlib.util.spec_from_file_location("schema_module", "6.schema.py")
    schema_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(schema_module)
    schema_context = schema_module.schema_context

    spec2 = importlib.util.spec_from_file_location("sql_module", "8.sql.py")
    sql_module = importlib.util.module_from_spec(spec2)
    spec2.loader.exec_module(sql_module)
    generate_sql = sql_module.generate_sql
    clean_sql = sql_module.clean_sql
    run_query = sql_module.run_query

    ctx = schema_context()
    question = input("Ask a business question about the data: ")

    sql = clean_sql(generate_sql(question, ctx))
    print("\nGenerated SQL:\n", sql)

    result_df = run_query(sql)
    print("\nResult shape:", result_df.shape)

    insight = generate_insight(question, result_df)
    print("\n--- Business Insight ---\n")
    print(insight)