import sqlite3
import pandas as pd

conn = sqlite3.connect("supply_chain.db")

orders = pd.read_sql(
    "SELECT order_date_time, expected_delivery_time, actual_delivery_time FROM orders LIMIT 3",
    conn
    )
print(orders)
print(orders.dtypes)

inventory = pd.read_sql(
    "SELECT last_updated FROM inventory LIMIT 3",
    conn
)
print(inventory)
print(inventory.dtypes)

returns = pd.read_sql(
    "SELECT return_date FROM returns LIMIT 3",
    conn
)
print(returns)
print(returns.dtypes)

delivery = pd.read_sql(
    "SELECT pickup_time, pickup_time_seconds, delivery_end_time, delivery_end_time_seconds FROM delivery LIMIT 3",
    conn
)
print(delivery)
print(delivery.dtypes)

conn.close()