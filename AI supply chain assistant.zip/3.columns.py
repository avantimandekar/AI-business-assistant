import sqlite3
import pandas as pd

conn = sqlite3.connect("supply_chain.db")

for table in ["delivery", "inventory", "orders", "products", "returns", "warehouses"]:
    df = pd.read_sql(f"SELECT * FROM {table} LIMIT 1", conn)
    print(f"{table}: {df.columns.tolist()}")

conn.close()
