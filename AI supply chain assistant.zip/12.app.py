import streamlit as st
import importlib.util


def load_module(alias, path):
    spec = importlib.util.spec_from_file_location(alias, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


schema_module = load_module("schema_module", "6.schema.py")
sql_module = load_module("sql_module", "8.sql.py")
insight_module = load_module("insight_module", "10.insight.py")
charts_module = load_module("charts_module", "11.charts.py")

schema_context = schema_module.schema_context
generate_sql = sql_module.generate_sql
clean_sql = sql_module.clean_sql
validate_sql = sql_module.validate_sql
run_query = sql_module.run_query
generate_insight = insight_module.generate_insight
auto_chart_from_result = charts_module.auto_chart_from_result


st.set_page_config(page_title="AI Business Analyst Assistant", layout="wide")
st.title("AI Business Analyst Assistant")
st.caption("Ask any business question about the supply chain data.")

ctx = schema_context()

question = st.text_input(
    "Ask a question:",
    placeholder="e.g. Why were deliveries late in February 2025? or Which products have the highest return rate?"
)

if st.button("Analyze") and question:
    with st.spinner("Generating SQL..."):
        raw_sql = clean_sql(generate_sql(question, ctx))
        try:
            sql = validate_sql(raw_sql)
        except ValueError as e:
            st.error(f"Query rejected for safety reasons: {e}")
            st.stop()

    with st.spinner("Running query..."):
        result_df = run_query(sql)

    if result_df.empty:
        st.error("No data returned — try rephrasing your question.")
        with st.expander("Show SQL used"):
            st.code(sql, language="sql")
    else:
        with st.spinner("Writing explanation..."):
            insight = generate_insight(question, result_df)

        with st.spinner("Building chart..."):
            fig = auto_chart_from_result(result_df, title=question)

        col1, col2 = st.columns(2)
        with col1:
            st.subheader("Answer")
            st.write(insight)
        with col2:
            st.subheader("Chart")
            if fig:
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No chartable numeric breakdown found for this result.")

        with st.expander("Show SQL used"):
            st.code(sql, language="sql")
        with st.expander("Show raw data"):
            st.dataframe(result_df)