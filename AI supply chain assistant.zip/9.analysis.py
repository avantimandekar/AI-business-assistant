import os
import pandas as pd
from google import genai

client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])


def explain_results(question, result_df, max_rows=15):
    """
    Works for ANY question — asks the LLM to interpret the SQL result.
    IMPORTANT: only sends a small sample + summary stats to the LLM,
    never the full table — large results (thousands of rows) would
    blow past free-tier token limits and cause a 429 error otherwise.
    """
    if result_df.empty:
        return "No rows were returned for this question — nothing to analyze."

    total_rows = len(result_df)

    # Small sample of actual rows, for the LLM to see real examples
    sample_preview = result_df.head(max_rows).to_string(index=False)

    # Basic summary stats for numeric columns, so the LLM has real numbers
    # even though it's not seeing every row
    numeric_cols = result_df.select_dtypes(include="number").columns.tolist()
    summary_text = ""
    if numeric_cols:
        summary_text = result_df[numeric_cols].describe().round(2).to_string()

    prompt = f"""You are a business analyst. A user asked this question about a supply chain database:

"{question}"

The SQL query returned {total_rows} total rows. Here is a sample of {min(max_rows, total_rows)} rows:
{sample_preview}

Summary statistics for numeric columns across all {total_rows} rows:
{summary_text if summary_text else "N/A"}

Based on this sample and the summary statistics, write a short, clear explanation
(3-6 sentences) of what the data shows and why, in plain English. Mention specific
numbers where relevant. Do not invent information not supported by the data above.
"""

    response = client.models.generate_content(
        model="gemini-3.6-flash",
        contents=prompt
    )
    return response.text.strip()


if __name__ == "__main__":
    import importlib.util

    spec = importlib.util.spec_from_file_location("schema_module", "6.schema.py")
    schema_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(schema_module)
    schema_context = schema_module.schema_context

    spec2 = importlib.util.spec_from_file_location("sql_module", "8.sql.py")
    sql_module = importlib.util.module_from_spec(spec2)
    spec2.loader.exec_module(sql_module)
    generate_sql = sql_module.generate_sql
    clean_sql = sql_module.clean_sql
    run_query = sql_module.run_query

    ctx = schema_context()
    question = input("Ask a question about the supply chain data: ")

    sql = clean_sql(generate_sql(question, ctx))
    print("\nGenerated SQL:\n", sql)

    result_df = run_query(sql)
    print("\nResult shape:", result_df.shape)

    print("\n--- Explanation ---\n")
    print(explain_results(question, result_df))