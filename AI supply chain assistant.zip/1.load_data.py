import os
import re
import pandas as pd
import sqlite3

folder = "data"

def clean_column_name(col):
    col = col.strip()
    col = re.sub(r'(?<=[a-z0-9])(?=[A-Z])', '_', col)
    col = col.replace(" ", "_")
    return col.lower()

conn = sqlite3.connect("supply_chain.db")

csv_files = [f for f in os.listdir(folder) if f.endswith(".csv")]

for file in csv_files:
    table_name = file.replace(".csv", "").lower()
    df = pd.read_csv(os.path.join(folder, file))
    df.columns = [clean_column_name(c) for c in df.columns]
    df.to_sql(table_name, conn, if_exists="replace", index=False)
    print(f"Loaded {table_name}: {df.shape[0]} rows, {df.shape[1]} cols")

conn.close()