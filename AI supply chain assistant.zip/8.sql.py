import os
import sqlite3
import pandas as pd
from google import genai

client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])


def call_llm(client, prompt, model="gemini-3.6-flash", retries=4):
    """Calls Gemini and retries on temporary overload (503) or rate-limit (429) errors."""
    import time
    for attempt in range(retries):
        try:
            return client.models.generate_content(model=model, contents=prompt).text.strip()
        except Exception as e:
            temporary = any(code in str(e) for code in ("503", "UNAVAILABLE", "429"))
            if temporary and attempt < retries - 1:
                time.sleep(3 * (attempt + 1))
                continue
            raise


def generate_sql(question, schema_ctx):
    prompt = f"""You are a SQL expert working with a SQLite database with multiple related tables.

{schema_ctx}

User question: "{question}"

Write a SQLite SELECT query that answers this question. For questions about rates, averages, comparisons,
"why" or "which", return an aggregated result (GROUP BY with counts, percentages or averages, ordered and
limited to the top rows), not raw order rows. Never treat pickup_time_seconds or delivery_end_time_seconds
as durations.
For "why" or overall-performance questions, return network-wide figures for ALL orders (total orders, late
percentage, average delivery minutes, average delay minutes) in one row, or add a breakdown by only ONE dimension
(for example store or delivery partner) using HAVING COUNT(*) >= 30. Never GROUP BY two dimensions at once, and do
not use LIMIT to keep only the worst rows when the question is about overall performance.
For ranking or list questions ("which stores", "which products", "top", "highest", "lowest", "most", "least")
return the top 10 rows with ORDER BY ... LIMIT 10. Use LIMIT 1 only if the user clearly asks for a single
item ("the one", "the single", "which store has the highest" in the singular). Never use LIMIT 1 for a plural question.

Rules:
- Only SELECT — never modify data.
- Use JOINs based only on the Table Relationships listed above.
- Use exact table and column names from the schema (all lowercase with underscores).
- For any time filtering, use order_date_time, expected_delivery_time, actual_delivery_time, last_updated, or return_date — never pickup_time or delivery_end_time directly (use pickup_time_seconds / delivery_end_time_seconds if duration is needed).
- If comparing periods, include both the period asked about and the immediately preceding period of the same length.
- Return ONLY the raw SQL. No explanation, no markdown fences.
"""
    return call_llm(client, prompt)


def clean_sql(raw_sql):
    """Strips markdown formatting only — NOT a safety check."""
    return raw_sql.replace("```sql", "").replace("```", "").strip()


def validate_sql(sql):
    """
    safety check: only allow SELECT queries, block anything destructive.
    Raises ValueError if the query is unsafe.
    """
    normalized = sql.strip().lower()
    if not normalized.startswith("select"):
        raise ValueError(f"Rejected: query does not start with SELECT.\nSQL was:\n{sql}")

    forbidden = ["drop", "delete", "update", "insert", "alter", "truncate", "attach", "pragma"]
    for word in forbidden:
        if word in normalized:
            raise ValueError(f"Rejected: query contains forbidden keyword '{word}'.\nSQL was:\n{sql}")

    return sql


def run_query(sql, db_path="supply_chain.db"):
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        df = pd.read_sql(sql, conn)
    except Exception as e:
        print(f"Query failed: {e}\nSQL was:\n{sql}")
        df = pd.DataFrame()
    finally:
        conn.close()
    return df


if __name__ == "__main__":
    import importlib.util

    spec = importlib.util.spec_from_file_location("schema_module", "6.schema.py")
    schema_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(schema_module)
    schema_context = schema_module.schema_context

    ctx = schema_context()
    question = input("Ask a question about the supply chain data: ")

    sql = clean_sql(generate_sql(question, ctx))
    sql = validate_sql(sql)  
    print("Generated SQL:\n", sql)

    result_df = run_query(sql)
    print("\nResult shape:", result_df.shape)
    print(result_df.head())