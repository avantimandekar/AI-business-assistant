import plotly.express as px
import pandas as pd


def make_bar_chart(series_or_df, title="Result", y_label="Value"):
    """
    Generic bar chart. Accepts either:
    - a pandas Series (e.g. groupby().mean() result) -> index becomes x-axis
    - a DataFrame with exactly 2 columns -> first column is x-axis, second is y-axis
    Returns a plotly figure, or None if the data can't be charted.
    """
    if series_or_df is None:
        return None

    if isinstance(series_or_df, pd.Series):
        df = series_or_df.reset_index()
        df.columns = ["category", "value"]
    elif isinstance(series_or_df, pd.DataFrame):
        if series_or_df.shape[1] < 2:
            return None
        df = series_or_df.iloc[:, :2].copy()
        df.columns = ["category", "value"]
    else:
        return None

    df["category"] = df["category"].astype(str)

    fig = px.bar(df, x="category", y="value", title=title, labels={"value": y_label})
    return fig


def _is_id_column(col_name):
    """ID-like columns (product_id, store_id, order_id, etc.) are identifiers,
    not meaningful metrics, and should never be auto-picked as a chart's y-axis."""
    name = col_name.lower()
    return name == "id" or name.endswith("_id") or name.endswith("id")


def auto_chart_from_result(result_df, title="Query Result"):
    """
    Tries to automatically build a sensible chart from ANY query result,
    for the AI Business Analyst Assistant use case.

    Picks the first non-numeric column as x-axis (e.g. product_name, store_name).
    Picks the first numeric column that is NOT an ID column as y-axis
    (e.g. total_amount, quantity, delay_minutes) — ID columns like product_id
    or order_id are identifiers, not metrics, and are explicitly skipped so
    charts don't plot meaningless values like "product_id: 1025".

    Returns None if no suitable columns exist (e.g. only ID-type numeric
    columns are present, or the result has fewer than 2 rows).

    Uses positional (.iloc) selection rather than name-based selection,
    because SQL joins can produce duplicate column names — selecting by
    name in that case can accidentally return more than one column.
    """
    if result_df is None or result_df.empty or len(result_df) < 2:
        return None

    numeric_cols = result_df.select_dtypes(include="number").columns.tolist()
    non_numeric_cols = result_df.select_dtypes(exclude="number").columns.tolist()

    # Filter out ID-like columns from numeric candidates — they're identifiers,
    # not business metrics, and are meaningless when plotted as bar heights.
    metric_cols = [c for c in numeric_cols if not _is_id_column(c)]

    if not metric_cols or not non_numeric_cols:
        return None

    x_col_name = non_numeric_cols[0]
    # Prefer a performance metric (percentage, rate, delay, average) over a plain count such as total_orders,
    # so the chart shows what the question is about.
    preferred_words = ("percent", "pct", "rate", "delay", "avg", "average", "minutes")
    preferred = [c for c in metric_cols if any(w in c.lower() for w in preferred_words)]
    y_col_name = preferred[0] if preferred else metric_cols[0]

    x_pos = list(result_df.columns).index(x_col_name)
    y_pos = list(result_df.columns).index(y_col_name)

    chart_df = result_df.iloc[:20, [x_pos, y_pos]].copy()  # cap at 20 bars for readability
    chart_df.columns = ["category", "value"]
    chart_df["category"] = chart_df["category"].astype(str)

    fig = px.bar(chart_df, x="category", y="value", title=title, labels={"value": y_col_name})
    return fig