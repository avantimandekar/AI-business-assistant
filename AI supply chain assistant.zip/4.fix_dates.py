import sqlite3
import pandas as pd

conn = sqlite3.connect ("supply_chain.db")

# orders_table
orders = pd.read_sql("SELECT * FROM orders", conn)
orders["order_date_time"] = pd.to_datetime(orders["order_date_time"])
orders["expected_delivery_time"] = pd.to_datetime(orders["expected_delivery_time"])
orders["actual_delivery_time"] = pd.to_datetime(orders["actual_delivery_time"])
orders.to_sql("orders", conn, if_exists="replace", index=False)
print("orders dates fix")

# inventory_table
inventory = pd.read_sql("SELECT * FROM inventory", conn)
inventory["last_updated"] = pd.to_datetime(inventory["last_updated"])
inventory.to_sql("inventory", conn, if_exists="replace", index=False)
print("inventory dates fix")

# returns_table
returns = pd.read_sql("SELECT * FROM returns", conn)
returns["return_date"] = pd.to_datetime(returns["return_date"])
returns.to_sql("returns", conn, if_exists="replace", index=False)
print("returns dates fix")

# delivery_table time into duration (seconds)
delivery = pd.read_sql("SELECT * FROM delivery", conn)

def time_str_to_seconds (t):
    minutes, seconds = t.split(":")
    return int(minutes) * 60 + float(seconds)

delivery["pickup_time_seconds"] = delivery["pickup_time"].apply(time_str_to_seconds)
delivery["delivery_end_time_seconds"] = delivery["delivery_end_time"].apply(time_str_to_seconds)
delivery.to_sql("delivery", conn, if_exists="replace", index=False)
print("delivery time fix")

conn.close()

print("done")