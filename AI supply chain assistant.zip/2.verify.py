import sqlite3
import pandas as pd

conn = sqlite3.connect ("supply_chain.db")

tables = pd.read_sql("SELECT name FROM sqlite_master WHERE type='table'", conn)
print(tables)

for t in tables["name"]:
    n = pd.read_sql(f"SELECT COUNT(*) as n FROM {t}", conn).iloc[0]["n"]
    print(f"{t}: {n} rows")

conn.close()